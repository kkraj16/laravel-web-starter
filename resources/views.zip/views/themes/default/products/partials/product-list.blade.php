@if($products->count() > 0)
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">

        @foreach($products as $product)
            <div class="group relative">
                <div class="aspect-[4/5] bg-gray-100 overflow-hidden relative mb-4">
                    @if($product->gallery && count($product->gallery) > 0)
                        <img 
                            src="{{ asset('storage/' . $product->gallery[0]) }}" 
                            alt="{{ $product->name }}" 
                            class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        >
                        @if(isset($product->gallery[1]))
                            <img 
                                src="{{ asset('storage/' . $product->gallery[1]) }}" 
                                alt="{{ $product->name }}" 
                                class="absolute inset-0 w-full h-full object-cover opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                            >
                        @endif
                    @elseif($product->thumbnail)
                        <img 
                            src="{{ asset('storage/' . $product->thumbnail) }}" 
                            alt="{{ $product->name }}" 
                            class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        >
                    @elseif($product->primary_image)
                        <img 
                            src="{{ $product->primary_image }}" 
                            alt="{{ $product->name }}" 
                            class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        >
                    @else
                        <div class="w-full h-full flex items-center justify-center bg-gray-50 text-gray-300">
                            <i class="bi bi-card-image text-4xl"></i>
                        </div>
                    @endif


                    @if($product->created_at->diffInDays(now()) < 30)
                        <span class="absolute top-2 left-2 bg-black text-white text-[10px] uppercase font-bold tracking-widest px-2 py-1">New</span>
                    @endif

                    @if($product->stock_status == 'outofstock')
                        <div class="absolute inset-0 bg-white/60 flex items-center justify-center">
                            <span class="bg-red-500 text-white px-3 py-1 text-xs uppercase tracking-widest font-bold shadow-md">Out of Stock</span>
                        </div>
                    @endif

                    <div class="absolute bottom-4 left-0 right-0 px-4 translate-y-full opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                        @if($product->stock_status == 'outofstock')
                            <button 
                                class="w-full bg-gray-300 text-gray-500 text-xs font-bold uppercase py-3 shadow-lg cursor-not-allowed flex items-center justify-center gap-2"
                                disabled
                            >
                                <i class="bi bi-x-circle"></i> Currently Unavailable
                            </button>
                        @else
                            <div class="grid grid-cols-2 gap-2">
                                <a 
                                    href="{{ route('products.show', $product->slug) }}"
                                    class="bg-black text-white text-xs font-bold uppercase py-3 shadow-lg hover:bg-primary hover:text-black transition-colors flex items-center justify-center gap-2"
                                >
                                    <i class="bi bi-eye"></i> Details
                                </a>
                                <button 
                                    class="bg-white text-black text-xs font-bold uppercase py-3 shadow-lg hover:bg-black hover:text-white transition-colors flex items-center justify-center gap-2"
                                    data-product-inquiry
                                    data-product-name="{{ $product->name }}"
                                    data-product-sku="{{ $product->sku ?? 'N/A' }}"
                                    data-product-price="₹{{ number_format($product->price, 0) }}"
                                    data-product-url="{{ route('products.short', $product->id) }}"
                                    data-whatsapp-number="{{ \App\Models\Setting::get('contact_whatsapp') ?? '919928154903' }}"
                                >
                                    <i class="bi bi-whatsapp text-green-500"></i> Inquire
                                </button>
                            </div>
                        @endif
                    </div>

                </div>

                <div class="text-center">
                    <h3 class="font-serif text-lg mb-1 group-hover:text-primary transition-colors">
                        <a href="{{ route('products.show', $product->slug) }}">{{ $product->name }}</a>
                    </h3>
                    <div class="flex flex-wrap justify-center gap-2 text-xs text-gray-500 uppercase tracking-wider mb-2">
                        @if($product->purity)
                            <span>{{ $product->purity }}</span>
                        @endif
                        @if($product->material)
                            <span>{{ $product->material }}</span>
                        @endif
                    </div>
                    
                    @php
                        $hidePrices = \App\Models\Setting::get('hide_prices', 0);
                    @endphp
                    
                    @if($hidePrices)
                        <p class="font-medium text-primary uppercase text-xs tracking-widest">Price on Request</p>
                    @else
                        @if($product->sale_price && $product->sale_price < $product->price)
                            <div class="flex items-center justify-center gap-2">
                                <span class="text-gray-400 line-through text-xs">₹{{ number_format($product->price, 0) }}</span>
                                <span class="text-red-600 font-bold">₹{{ number_format($product->sale_price, 0) }}</span>
                            </div>
                        @else
                            <p class="font-medium">₹{{ number_format($product->price, 0) }}</p>
                        @endif
                    @endif
                </div>
            </div>
        @endforeach
    </div>

    <!-- Pagination -->
    <div class="mt-12 flex justify-center">
        {{ $products->links() }}
    </div>
@else
    <div class="flex flex-col items-center justify-center py-20 bg-gray-50 text-center px-4">
        <i class="bi bi-search text-4xl text-gray-300 mb-4"></i>
        <h3 class="font-serif text-2xl mb-2">No masterpieces found</h3>
        <p class="text-gray-500 font-light max-w-md mx-auto mb-6">We couldn't find any products matching your specific requirements. Try adjusting your filters.</p>
        <button @click="clearFilters()" class="text-xs font-bold uppercase tracking-widest border-b border-black pb-1 hover:text-primary hover:border-primary transition-colors">
            Clear all filters
        </button>
    </div>
@endif
